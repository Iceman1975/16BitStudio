Several 16x16 platform icons are from this page:
http://neuropod.net/console16.html
"Here's a collection of video game console icons, 16x16, hand-sprited by me.
As seen on SDB. Use 'em for whatever!"
