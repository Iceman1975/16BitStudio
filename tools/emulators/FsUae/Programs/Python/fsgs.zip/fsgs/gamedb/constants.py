DATABASE_AMIGA = "openretro.org/amiga"
