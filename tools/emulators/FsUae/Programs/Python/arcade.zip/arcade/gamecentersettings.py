class GameCenterSettings:
    @classmethod
    def get_shutdown_command(cls):
        pass
