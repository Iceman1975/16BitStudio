# FIXME: compatibility module - remove
# noinspection PyUnresolvedReferences
# from fengestad.game.platform import GamePlatform as Platform
