# noinspection PyPep8Naming
def SDL_Maximize():
    pass


# noinspection PyPep8Naming
def SDL_Restore():
    pass


# noinspection PyPep8Naming
def SDL_Minimize():
    pass


# noinspection PyPep8Naming
def SDL_IsMaximized():
    return False


# noinspection PyPep8Naming
def SDL_IsMinimized():
    return False
