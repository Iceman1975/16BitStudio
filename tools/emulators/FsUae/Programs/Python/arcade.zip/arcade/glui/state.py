from arcade.glui.render import Render

State = Render
