#
# def main(main_window):
#     from arcade.glui.settings import Settings
#
#     try:
#         import arcade.glui.window
#         arcade.glui.window.main_window = main_window
#         arcade.glui.window.show()
#     except Exception as e:
#         import traceback
#         print("\n" + "-" * 79 + "\n" + "EXCEPTION")
#         traceback.print_exc()
#         show_error(repr(e), traceback.format_exc(e))
#
#     print(" --- arcade.glui.main is done ---")
