import fsui.web


class WebView(fsui.web.WebView):
    pass
