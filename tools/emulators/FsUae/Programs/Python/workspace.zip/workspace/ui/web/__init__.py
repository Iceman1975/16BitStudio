# noinspection PyUnresolvedReferences
from workspace.ui.web_view import WebView
