import fsui


class ImageView(fsui.ImageView):
    pass
