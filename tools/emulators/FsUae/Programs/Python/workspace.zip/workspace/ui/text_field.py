import fsui


class TextField(fsui.TextField):
    pass
