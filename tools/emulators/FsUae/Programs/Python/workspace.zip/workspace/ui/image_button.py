import fsui


class ImageButton(fsui.ImageButton):
    pass
