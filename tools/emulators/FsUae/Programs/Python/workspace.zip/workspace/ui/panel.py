import fsui


class Panel(fsui.Panel):

    def __init__(self, parent):
        super().__init__(parent)
        # self.set_background_color(fsui.Color(0xf2, 0xf2, 0xf2))
